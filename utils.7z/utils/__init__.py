# Create an empty __init__.py file
